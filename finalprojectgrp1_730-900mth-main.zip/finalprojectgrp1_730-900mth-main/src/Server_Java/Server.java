package Server_Java;

import CORBA_IDL.wordy;
import CORBA_IDL.wordyPOA;
import Client_Java.myConnection;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Server {
    public static void main(String args[]) {
        try {
            // create and initialize the ORB
            ORB orb = ORB.init(args, null);

            // get reference to root POA and activate the POAManager
            POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootPOA.the_POAManager().activate();

            // create servant and register it with the ORB
            ServerImpl wordy = new ServerImpl();
            org.omg.CORBA.Object ref = rootPOA.servant_to_reference(wordy);
            wordy href = CORBA_IDL.wordyHelper.narrow(ref);
            // bind the object reference to the naming service
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            NameComponent[] path = ncRef.to_name("Hello");
            ncRef.rebind(path, href);

            // wait for incoming requests
            orb.run();
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }
    }
}
/**
 * login;
 * start join game;
 * obtain 17 characters random
 * sendwords; with player (kung sino nag send)
 * endGame;
 * endRound;
 * wonRoundOrNot;
 * gameEnded;
 * longestWord;
 * topPlayers;(ranking)
 */
