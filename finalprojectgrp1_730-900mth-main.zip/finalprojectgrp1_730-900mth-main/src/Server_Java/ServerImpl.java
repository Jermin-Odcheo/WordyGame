package Server_Java;

import Client_Java.myConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ServerImpl  extends CORBA_IDL.wordyPOA{
    @Override
    public void login(String username, String password) {
        PreparedStatement preparedStatement;
        ResultSet resultSet;
        try {
            preparedStatement = myConnection.getConnection().prepareStatement("SELECT * FROM `users` WHERE user_username =? AND user_password =?");
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,password);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                throw new Exception("Successfully Logged In!");
            } else {
                throw new Exception("Failed To Logged In!");
            }
        } catch (Exception e){
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }
}
